
// Minimal SSRF guard for extension-side fetches to admin-configured endpoints.
// Mirrors the worker's isBlockedHost for the common private/loopback cases.
function isSafeOutboundUrlBg(raw) {
  if (!raw) return false;
  let u;
  try { u = new URL(String(raw)); } catch (e) { return false; }
  if (u.protocol !== 'https:') return false;
  let host = String(u.hostname || '').toLowerCase();
  if (host.startsWith('[') && host.endsWith(']')) host = host.slice(1, -1);
  host = host.replace(/\.$/, '');
  if (!host) return false;
  if (host === 'localhost' || host.endsWith('.localhost')) return false;
  if (host.endsWith('.local') || host.endsWith('.internal')) return false;
  if (host.includes(':')) {
    if (host === '::1' || host === '0:0:0:0:0:0:0:1' || host === '::' || host === '0:0:0:0:0:0:0:0') return false;
    const first = host.split(':')[0];
    if (/^fe[89ab][0-9a-f]$/.test(first) || /^f[cd][0-9a-f]{2}$/.test(first) || host.startsWith('::ffff:')) return false;
    return true;
  }
  const parts = host.split('.');
  if (parts.length === 4 && parts.every(s => /^\d{1,3}$/.test(s))) {
    const p = parts.map(Number);
    if (p[0] === 10) return false;
    if (p[0] === 172 && p[1] >= 16 && p[1] <= 31) return false;
    if (p[0] === 192 && p[1] === 168) return false;
    if (p[0] === 169 && p[1] === 254) return false;
    if (p[0] === 127) return false;
    if (p[0] === 0) return false;
  }
  return true;
}

/**
 * API Key Leak Intercept: service worker
 *
 * Handles: storage defaults, month-aware warning counters, badge updates,
 * message routing from popup/content, alert forwarding (team mode) plus
 * cloud relay, license verification, and update checks.
 */
const WORKER_URL = 'https://api.dariocositore.com';
const RESEND_FROM = 'API Key Leak Intercept <alerts@api-key-leak-intercept.dev>';

// Every request this worker makes goes through here so it gets a deadline.
// MV3 keeps the worker alive only while something is waiting on it, so a fetch
// that never settled meant sendResponse was never called: getSettings answered
// nothing, the popup's callback ran with undefined and it rendered its markup
// defaults, which for a Pro install is the Free artboard with no error
// anywhere. Eight seconds is generous for all of these, and every caller
// already has a catch that treats a failure as "keep what we have".
function swFetch(url, init) {
  const opts = Object.assign({}, init || {});
  if (!opts.signal) {
    try {
      if (typeof AbortSignal !== 'undefined' && typeof AbortSignal.timeout === 'function') {
        opts.signal = AbortSignal.timeout(8000);
      }
    } catch (e) {}
  }
  return fetch(url, opts);
}

const DEFAULTS = {
  sg_settings: {
    // Personal installs start with protection off; the welcome page carries
    // the disclosure and the explicit Enable step. Managed installs force it
    // on (see content.js policy handling).
    enabled: false,
    categories: { apiKeys: true, pii: false, network: false },
    customPatterns: [],
    autoRedact: false,
  },
  sg_leaks_stopped: 0,
  sg_leaks_month: '',
  sg_hide_pro_hint: false,
  sg_isPro: false,
  sg_license_key: '',
  sg_license_invalid: false,
  sg_org: {
    teamMode: false,
    orgId: '',
    orgToken: '',
    userEmail: '',
    universalMode: false,
    extraEmails: '',
    alertOnWarn: true,
    alertOnSendAnyway: true,
    alertOnBlock: true,
    alertOnRedact: true,
    heartbeat: false,
    extraSites: [],
    alertEndpoint: '',
    blockSendAnyway: false,
    channels: {
      slack: { enabled: false, webhookUrl: '' },
      teams: { enabled: false, webhookUrl: '' },
      telegram: { enabled: false, botToken: '', chatId: '' },
      webhook: { enabled: false, url: '' },
      email: { enabled: false, apiKey: '', to: '' },
    },
  },
};

/* ------------------------------------------------------------------ */
/* Effective org (managed policy over local settings)                  */
/* ------------------------------------------------------------------ */
// Enterprise policy is the stronger half: policy org fields override the
// stored sg_org, and a policy orgId turns team mode on. Managed installs
// with an org heartbeat unless the policy sets heartbeat:false.
function getEffectiveOrg(cb) {
  chrome.storage.local.get(['sg_org'], (res) => {
    const org = { ...DEFAULTS.sg_org, ...(res.sg_org || {}) };
    const apply = (m) => {
      if (m && Object.keys(m).length > 0) {
        if (m.orgId) { org.orgId = String(m.orgId); org.teamMode = true; }
        if (m.orgToken) org.orgToken = String(m.orgToken);
        if (m.userEmail) org.userEmail = String(m.userEmail);
        if (typeof m.universalMode === 'boolean') org.universalMode = m.universalMode;
        // extraSites is a documented policy key and is what widens the dynamic
        // content script beyond the built-in list. Leaving it out of this merge
        // meant a policy-only install registered no script at all.
        if (Array.isArray(m.extraSites)) org.extraSites = m.extraSites.map(String);
        if (m.alertEndpoint) org.alertEndpoint = String(m.alertEndpoint);
        for (const k of ['alertOnWarn', 'alertOnSendAnyway', 'alertOnBlock', 'alertOnRedact']) {
          if (typeof m[k] === 'boolean') org[k] = m[k];
        }
        if (m.orgId && m.heartbeat !== false) org.heartbeat = true;
        else if (typeof m.heartbeat === 'boolean') org.heartbeat = m.heartbeat;
      }
      cb(org);
    };
    try {
      if (chrome.storage && chrome.storage.managed) {
        chrome.storage.managed.get(null, (m) => apply(m));
        return;
      }
    } catch (e) {}
    apply(null);
  });
}

/* ------------------------------------------------------------------ */
/* Pro entitlement (server-confirmed)                                  */
/* ------------------------------------------------------------------ */
// Pro capabilities for team installs require a live license on the org.
// The answer is cached with a TTL plus a grace window (see
// entitlement-state.js) and a definitive pro:false revokes immediately.
async function checkEntitlement() {
  try {
    const org = await new Promise((resolve) => getEffectiveOrg(resolve));
    if (!org.teamMode || !org.orgId || !org.orgToken) return;
    // installId is what ties the seat to this machine: the worker grants team
    // Pro per install, so an org past its cap loses it on the machines it did
    // not pay for rather than on all of them at once.
    const r = await swFetch(WORKER_URL + '/api/entitlement', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orgId: org.orgId, orgToken: org.orgToken, installId: await getInstallId() }),
      cache: 'no-store',
    });
    // A rotated ingest token answers 401 and a deleted org answers 404. Both
    // are the server actively refusing this install, not a network blip, and
    // the policy above is that a definitive refusal revokes at once. Leaving
    // the cache untouched on those two left a terminated install entitled for
    // the whole TTL plus grace, 21 days, and kept its seat warm. verifyLicense
    // already treats a definitive invalid as a revocation; this path did not.
    if (r.status === 401 || r.status === 404) {
      await new Promise((resolve) => chrome.storage.local.set({
        sg_entitlement: { pro: false, orgId: org.orgId, at: Date.now() },
      }, resolve));
      broadcastSettingsUpdated();
      return;
    }
    const data = await r.json();
    if (data && data.ok) {
      await new Promise((resolve) => chrome.storage.local.set({
        sg_entitlement: { pro: !!data.pro, orgId: org.orgId, at: Date.now() },
      }, resolve));
      broadcastSettingsUpdated();
    }
  } catch (e) {}
}

/* ------------------------------------------------------------------ */
/* Month-aware warning counter                                         */
/* ------------------------------------------------------------------ */
function currentMonth() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
}

function withNormalizedLeaks(cb) {
  chrome.storage.local.get(['sg_leaks_stopped', 'sg_leaks_month'], (res) => {
    const month = currentMonth();
    let n = res.sg_leaks_stopped || 0;
    if (res.sg_leaks_month !== month) {
      n = 0;
      chrome.storage.local.set({ sg_leaks_stopped: 0, sg_leaks_month: month });
    }
    cb(n);
  });
}

/* ------------------------------------------------------------------ */
/* Install / defaults                                                  */
/* ------------------------------------------------------------------ */
// Alarms were created here and nowhere else. Chrome does not promise they
// survive a profile repair or a browser update, and when they vanish the daily
// licence revalidation, the entitlement refresh, the config fetch and the
// six-hourly seat heartbeat all stop silently until the next extension update.
// Creating a same-named alarm cancels the running one and restarts its
// countdown, so re-asserting unconditionally on every service worker start
// reset the 24-hour licence check faster than it could ever fire. Only create
// what is missing; a running alarm is left exactly as it is.
function ensureAlarm(name, periodInMinutes) {
  try {
    chrome.alarms.get(name, (existing) => {
      if (existing) return;
      try { chrome.alarms.create(name, { periodInMinutes }); } catch (e) {}
    });
  } catch (e) {}
}
function ensureAlarms() {
  ensureAlarm('licenseCheck', 1440);
  ensureAlarm('heartbeat', 360);
  ensureAlarm('configCheck', 1440);
}
ensureAlarms();

chrome.runtime.onInstalled.addListener((details) => {
  ensureAlarms();
  try {
    // the uninstall survey, with the version for context. deliberately no
    // browsing data: the privacy page promises the extension sends none
    const unV = chrome.runtime.getManifest().version;
    chrome.runtime.setUninstallURL(
      'https://dariocositore.com/tools/api-key-leak-intercept/uninstall/?utm_medium=internal&utm_campaign=extensionUninstall&extensionName=chrome&extensionVersion=' + encodeURIComponent(unV));
  } catch (e) {}
  if (details && details.reason === 'install') {
    try { chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') }); } catch (e) {}
  }
  try { fetchConfig(); } catch (e) {}
  try { syncDynamicContentScript(); } catch (e) {}
  chrome.storage.local.get(Object.keys(DEFAULTS), (res) => {
    const toSet = {};
    for (const k of Object.keys(DEFAULTS)) {
      if (res[k] === undefined) toSet[k] = DEFAULTS[k];
    }
    if (res.sg_leaks_month === undefined) toSet.sg_leaks_month = currentMonth();
    // migrate: PII/network detection is Pro-only from 1.0.0 on. Both flags,
    // so a stale sg_isPro cannot keep the paid categories switched on while
    // the popup reports Free.
    if (res.sg_settings && res.sg_settings.categories && res.sg_settings.categories.pii
        && !(res.sg_isPro && res.sg_license_key)) {
      const cats = { ...res.sg_settings.categories, pii: false, network: false };
      toSet.sg_settings = { ...res.sg_settings, categories: cats };
    }
    if (Object.keys(toSet).length) chrome.storage.local.set(toSet);
  });
  chrome.action.setBadgeText({ text: '' });
  chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
});

/* ------------------------------------------------------------------ */
/* Messaging                                                           */
/* ------------------------------------------------------------------ */
// Handshake from the License & Team Console after sign-in. The page opens from
// the popup's Sign in button, the user signs in on the web, the page passes the
// licence key back here and closes itself. Manifest restricts this to
// dariocositore.com via externally_connectable.
// Guarded: the API is absent from test harness stubs and from runtimes that
// predate it, and the extension must still load there.
if (chrome.runtime && chrome.runtime.onMessageExternal) {
  chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
    try {
      const allowed = !!sender && /^https:\/\/(www\.)?dariocositore\.com\//.test(sender.url || '');
      if (!allowed) { sendResponse({ ok: false, error: 'untrusted sender' }); return; }
      if (msg && msg.type === 'akliAuth' && msg.licenseKey) {
        // A tab opened with chrome.tabs.create is not script-closable, so the
        // extension closes it once the key is verified. That drops the user back
        // into the popup the way the web login flow is meant to feel.
        verifyLicense(msg.licenseKey, (res) => {
          try {
            if (res && res.valid && sender && sender.tab && sender.tab.id != null) {
              chrome.tabs.remove(sender.tab.id).catch(() => {});
            }
          } catch (e) {}
          sendResponse(res);
        });
        return true;
      }
      sendResponse({ ok: false, error: 'unknown message' });
    } catch (e) {
      sendResponse({ ok: false, error: String(e && e.message || e) });
    }
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {  if (!msg) return;

  if (msg.type === 'getSettings') {
    withNormalizedLeaks((n) => {
      chrome.storage.local.get(['sg_settings', 'sg_isPro', 'sg_license_key', 'sg_license_invalid', 'sg_hide_pro_hint', 'sg_entitlement'], (res) => {
        getEffectiveOrg((org) => {
          const respond = () => {
            sendResponse({
              settings: res.sg_settings || DEFAULTS.sg_settings,
              leaksStopped: n,
              isPro: !!res.sg_isPro && !!res.sg_license_key,
              licenseInvalid: !!res.sg_license_invalid,
              org,
              hideProHint: !!res.sg_hide_pro_hint,
              entitled: SGEntitlement.entitledFrom(res.sg_entitlement, org.orgId),
            });
          };
          // Answering before the refresh landed reported the state the fetch
          // was about to replace, so a lapsed cache showed Free until the
          // popup was opened again. Await the refresh, then read the cache it
          // wrote; on failure the old record stands and grace still applies.
          // Bounded at three seconds: hold the popup for a quick refresh, but
          // never let one stall keep it from rendering at all. A stale answer
          // inside grace is correct, a blank popup is not, and the refresh
          // still lands in storage whenever it finishes.
          if (SGEntitlement.needsRefresh(res.sg_entitlement, org.orgId) && org.teamMode && org.orgId && org.orgToken) {
            Promise.race([
              checkEntitlement(),
              new Promise((r) => setTimeout(r, 3000)),
            ]).finally(() => chrome.storage.local.get(['sg_entitlement'], (fresh) => {
              res.sg_entitlement = fresh.sg_entitlement;
              respond();
            }));
          } else {
            respond();
          }
        });
      });
    });
    return true;
  }

  if (msg.type === 'getManagedState') {
    withManagedState((managed) => sendResponse({ managed: !!managed }));
    return true;
  }

  if (msg.type === 'saveSettings') {
    isSettingsLocked((locked) => {
      if (locked) { sendResponse({ ok: false, locked: true }); return; }
      const commit = () => {
        chrome.storage.local.set({ sg_settings: msg.settings }, () => {
          broadcastSettingsUpdated();
          sendResponse({ ok: true });
        });
      };
      // A force install's user does not get the pause switch, with or without
      // lockSettings in policy: a managed install may only ever store
      // enabled === true. Detection is re-forced on for managed installs
      // regardless, so the scan never actually stopped before this -- but the
      // record would sit there reading "off" on a machine nobody re-configures,
      // and "make me invisible" is the one setting an employee must not own.
      if (!msg.settings || msg.settings.enabled !== true) {
        machineLocked((locked) => {
          if (locked) { sendResponse({ ok: false, locked: true }); return; }
          commit();
        });
        return;
      }
      commit();
    });
    return true;
  }

  if (msg.type === 'saveOrg') {
    isSettingsLocked((locked) => {
      if (locked) { sendResponse({ ok: false, locked: true }); return; }
      const next = msg.org || {};
      chrome.storage.local.get(['sg_org'], (cur) => {
        const had = String((cur && cur.sg_org && cur.sg_org.orgId) || '');
        if (had && !String(next.orgId || '')) {
          // Nothing in the popup can turn enrollment off any more -- the
          // controls that used to are gone -- so a write that drops orgId is a
          // bug or a stale screen, never a user decision. Losing it stops the
          // heartbeat, the alert relay and the entitlement refresh while the
          // licence itself keeps working, which is exactly how an organization
          // vanishes without anything ever throwing.
          sendResponse({ ok: false, locked: true, reason: 'org' });
          return;
        }
        // An org ID without team mode is the same record half broken: every
        // consumer gates on both, so it would look enrolled and do nothing.
        if (String(next.orgId || '')) next.teamMode = true;
        chrome.storage.local.set({ sg_org: next }, () => {
          broadcastSettingsUpdated();
          checkEntitlement().finally(() => sendResponse({ ok: true }));
        });
      });
    });
    return true;
  }

  if (msg.type === 'incrementLeaksStopped') {
    // Through the same queue as the audit log. Two catches in the same second
    // read the same n and both wrote n+1, so one increment was silently lost
    // and the "leaks stopped" number undercounted.
    auditWriteQueue = auditWriteQueue.then(() => new Promise((resolve) => {
      withNormalizedLeaks((n) => {
        const next = n + 1;
        chrome.storage.local.set({ sg_leaks_stopped: next, sg_leaks_month: currentMonth() }, () => {
          sendResponse({ count: next });
          resolve();
        });
      });
    }));
    return true;
  }

  if (msg.type === 'verifyLicense') {
    verifyLicense(msg.key, sendResponse);
    return true;
  }

  if (msg.type === 'accountLogin') {
    accountLogin(msg.email, msg.password, sendResponse);
    return true;
  }

  if (msg.type === 'accountLogout') {
    // The seat belongs to whoever owns the machine. Signing out would drop the
    // licence and Pro from a machine the organization is still paying for, and
    // nobody on it holds the key to put them back.
    machineLocked((locked) => {
      if (locked) { sendResponse({ ok: false, locked: true }); return; }
      chrome.storage.local.remove(['sg_account_email', 'sg_license_key', 'sg_isPro', 'sg_license_invalid', 'sg_entitlement'], () => sendResponse({ ok: true }));
    });
    return true;
  }

  if (msg.type === 'reverifyLicense') {
    chrome.storage.local.get(['sg_license_key'], (res) => {
      if (!res.sg_license_key) { sendResponse({ ok: false, reason: 'no key' }); return; }
      verifyLicense(res.sg_license_key, sendResponse);
    });
    return true;
  }

  if (msg.type === 'sendAlert') {
    handleAlert(msg.alert, sendResponse);
    return true;
  }

  if (msg.type === 'getAuditLog') {
    chrome.storage.local.get(['sg_audit_log'], (res) => {
      sendResponse({ log: res.sg_audit_log || [] });
    });
    return true;
  }

  if (msg.type === 'clearAuditLog') {
    chrome.storage.local.set({ sg_audit_log: [] }, () => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'openPopup') {
    try {
      chrome.runtime.openOptionsPage().then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    } catch (e) { sendResponse({ ok: false }); }
    return true;
  }

  if (msg.type === 'openUrl') {
    const ok = typeof msg.url === 'string' && /^https?:\/\//i.test(msg.url);
    if (ok) chrome.tabs.create({ url: msg.url });
    sendResponse({ ok });
    return false;
  }
});

function broadcastSettingsUpdated() {
  chrome.tabs.query({}, (tabs) => {
    for (const t of tabs) {
      if (t.id !== undefined) chrome.tabs.sendMessage(t.id, { type: 'settingsUpdated' }).catch(() => {});
    }
  });
}

/* ------------------------------------------------------------------ */
/* Managed policy (Chrome Enterprise)                                  */
/* ------------------------------------------------------------------ */
// Settings changes from the popup are rejected while policy holds lockSettings
function isSettingsLocked(cb) {
  try {
    if (chrome.storage && chrome.storage.managed) {
      chrome.storage.managed.get(['lockSettings'], (m) => cb(!!(m && m.lockSettings)));
      return;
    }
  } catch (e) {}
  cb(false);
}

// Managed = force-installed by an admin or configured through managed storage
function withManagedState(cb) {
  let admin = false;
  let policy = false;
  let pending = 2;
  const done = () => {
    pending -= 1;
    if (pending === 0) cb(admin || policy);
  };
  try {
    chrome.management.getSelf((info) => {
      if (info && info.installType === 'admin') admin = true;
      done();
    });
  } catch (e) { done(); }
  try {
    if (chrome.storage && chrome.storage.managed) {
      chrome.storage.managed.get(null, (m) => {
        if (m && Object.keys(m).length > 0) policy = true;
        done();
      });
    } else {
      done();
    }
  } catch (e) { done(); }
}

// Enterprise policy overrides the user's org preferences wherever the two
// meet; that merge lives in getEffectiveOrg above.

// Whether the machine belongs to somebody other than the person at it. Two
// routes, one answer: forced on by an administrator, or enrolled with an
// organization's setup code. Only the first was consulted until now, so a
// key-paired install kept a live pause switch while the dashboard went on
// reporting it as healthy.
function machineLocked(cb) {
  withManagedState((managed) => {
    if (managed) { cb(true); return; }
    chrome.storage.local.get(['sg_org'], (res) => {
      const org = (res && res.sg_org) || {};
      cb(!!(org.teamMode && org.orgId));
    });
  });
}

/* ------------------------------------------------------------------ */
/* Runtime content script registration                                 */
/* ------------------------------------------------------------------ */
// The manifest declares the content script for the built-in AI chat list only,
// so the install permission is scoped to those sites. Universal mode and
// org-supplied extra sites reach further, and that access is optional: the
// popup asks for it when the user turns the feature on, then this keeps the
// registered script in step with whatever is actually enabled.
const DYNAMIC_SCRIPT_ID = 'sg-dynamic-sites';
const DYNAMIC_JS = ['detect.js', 'entitlement-state.js', 'content.js'];
const DYNAMIC_CSS = ['content.css'];

function hostPatterns(hosts) {
  const out = [];
  const seen = new Set();
  for (const raw of hosts) {
    const h = String(raw || '').trim().toLowerCase();
    if (!h || /[^a-z0-9.\-]/.test(h)) continue;
    for (const p of ['*://' + h + '/*', '*://*.' + h + '/*']) {
      if (!seen.has(p)) { seen.add(p); out.push(p); }
    }
  }
  return out;
}

function dynamicMatchesFor(org, cfg) {
  if (org && org.universalMode) return ['<all_urls>'];
  const hosts = [];
  if (org && Array.isArray(org.extraSites)) hosts.push(...org.extraSites);
  if (cfg && Array.isArray(cfg.aiSites)) hosts.push(...cfg.aiSites);
  return hostPatterns(hosts);
}

async function syncDynamicContentScript() {
  if (!chrome.scripting || !chrome.scripting.getRegisteredContentScripts) return;
  let org = null;
  let cfg = null;
  try {
    // getEffectiveOrg, not the raw sg_org record. Managed policy is the only
    // source of universalMode and extraSites for a policy-only install, so
    // reading the local record alone computed matches = [] and unregistered
    // the dynamic script: the MDM rollout got no coverage outside the built-in
    // list, silently, until somebody opened the popup and pressed Save.
    org = await new Promise((resolve) => getEffectiveOrg(resolve));
    const res = await new Promise((r) => chrome.storage.local.get(['sg_config', 'sg_config_exp'], r));
    const cfgExpired = typeof res.sg_config_exp === 'number' && res.sg_config_exp * 1000 <= Date.now();
    cfg = cfgExpired ? {} : (res.sg_config || {});
  } catch (e) { return; }

  const matches = dynamicMatchesFor(org, cfg);
  try {
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [DYNAMIC_SCRIPT_ID] });
    if (!matches.length) {
      if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: [DYNAMIC_SCRIPT_ID] });
      return;
    }
    const spec = {
      id: DYNAMIC_SCRIPT_ID,
      js: DYNAMIC_JS,
      css: DYNAMIC_CSS,
      matches,
      runAt: 'document_idle',
      allFrames: false,
      persistAcrossSessions: true,
    };
    if (existing.length) await chrome.scripting.updateContentScripts([spec]);
    else await chrome.scripting.registerContentScripts([spec]);
  } catch (e) {
    // The optional host permission is not granted yet; the popup requests it
    // before flipping Universal on, so there is nothing to do here.
  }
}

chrome.storage.onChanged.addListener((changes) => {
  if (changes.sg_leaks_stopped) {
    const n = changes.sg_leaks_stopped.newValue || 0;
    chrome.action.setBadgeText({ text: n > 0 ? String(n) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
  }
  if (changes.sg_org || changes.sg_config || changes.sg_config_exp) {
    try { syncDynamicContentScript(); } catch (e) {}
  }
});

// Policy changes arrive through storage.managed and fire no other listener, so
// a managed install only picked up a new universalMode or extraSites after
// somebody opened the popup and saved. Registering the script is the whole
// point of those two keys, so policy has to re-sync on its own.
if (chrome.storage && chrome.storage.managed && chrome.storage.managed.onChanged) {
  try {
    chrome.storage.managed.onChanged.addListener(() => {
      try { syncDynamicContentScript(); } catch (e) {}
    });
  } catch (e) {}
}

/* ------------------------------------------------------------------ */
/* License verification (server-side revalidation included)            */
/* ------------------------------------------------------------------ */
// Account sign-in from the popup: email and password against the portal
// account minted at checkout. The reply carries the licence key, which is then
// pushed through the same verify-and-store path a pasted key takes, so Pro
// state ends up identical whichever way the user signs in.
function accountLogin(email, password, sendResponse) {
  const e = String(email || '').trim().toLowerCase();
  const p = String(password || '');
  if (!e || e.indexOf('@') < 1 || !p) {
    sendResponse({ ok: false, valid: false, error: 'enter your email and password' });
    return;
  }
  swFetch(WORKER_URL + '/api/account/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: e, password: p }),
    cache: 'no-store',
  })
    .then(r => r.json().then(data => ({ status: r.status, data })))
    .then(({ status, data }) => {
      if (data && data.ok && data.licenseKey) {
        chrome.storage.local.set({ sg_account_email: e }, () => {
          verifyLicense(data.licenseKey, sendResponse);
        });
        return;
      }
      if (data && data.ok) {
        // signed in fine, but nothing is licensed on this account
        chrome.storage.local.set({ sg_account_email: e }, () => {
          sendResponse({ ok: true, valid: false, noLicense: true, error: 'no license on this account yet' });
        });
        return;
      }
      sendResponse({
        ok: false, valid: false,
        error: (data && data.error) || ('sign in failed (' + status + ')'),
      });
    })
    .catch(() => sendResponse({ ok: false, valid: null, error: 'offline' }));
}

function verifyLicense(key, sendResponse) {
  const k = String(key || '').trim().toUpperCase();
  if (!k) { sendResponse({ ok: false, valid: false, error: 'missing key' }); return; }
  // installId is what the worker counts devices by. Without it one key still
  // works on any number of PCs, which is the reselling hole.
  getInstallId()
    .then((installId) => swFetch(WORKER_URL + '/api/license/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: k, installId }),
      cache: 'no-store',
    }))
    .then(r => r.json().then(data => ({ data })))
    .then(({ data }) => {
      // Revoke only on a definitive { valid: false } from the server.
      // Rate limits, 5xx, and malformed bodies leave Pro untouched.
      if (data && data.valid === true) {
        pruneAuditLog(data.logClearedAt);
        chrome.storage.local.set({ sg_isPro: true, sg_license_key: k, sg_license_invalid: false }, () => {
          broadcastSettingsUpdated();
          sendResponse({ ok: true, valid: true, email: data.email || '' });
        });
      } else if (data && data.valid === false) {
        chrome.storage.local.set({ sg_isPro: false, sg_license_invalid: true }, () => {
          broadcastSettingsUpdated();
          sendResponse({ ok: true, valid: false, error: data.error || 'invalid' });
        });
      } else {
        sendResponse({ ok: false, valid: null, error: (data && data.error) || 'unexpected response' });
      }
    })
    .catch(() => {
      // Offline / server unreachable: keep the current Pro state.
      sendResponse({ ok: false, valid: null, error: 'offline' });
    });
}

/* ------------------------------------------------------------------ */
/* Alert forwarding (team mode) + Pro local history                    */
/* ------------------------------------------------------------------ */
function handleAlert(alert, sendResponse) {
  if (!alert || !alert.action) { sendResponse({ ok: false, reason: 'bad alert' }); return; }

  withManagedState((managed) => {
    chrome.storage.local.get(['sg_isPro', 'sg_license_key'], (res) => {
      // Both flags, same rule as getSettings. Local history is a paid feature
      // and checking sg_isPro on its own reopened it to a stale flag with no
      // verification behind it, which is exactly the state the 1.2.4 fix was
      // written to close.
      const isPro = !!res.sg_isPro && !!res.sg_license_key;
      getEffectiveOrg((o) => {
      const isTeam = managed || !!(o.teamMode && o.orgId && alert.orgId);

      if (!isPro && !isTeam) { sendResponse({ ok: false, reason: 'personal free mode' }); return; }

      // Local audit log: Pro (personal history) or team mode
      storeAlertLocally(alert);

      if (!isTeam) {
        // Await the relay before answering. Responding first left the service
        // worker free to be terminated in the gap, losing the console relay and
        // its sync status while the local log already recorded the catch.
        Promise.resolve(sendPersonalAlert(alert)).catch(() => {}).then(() => {
          sendResponse({ ok: true, stored: true });
        });
        return;
      }

      // Alert preferences only control outbound notifications, not the log
        if (alert.action === 'blocked' && o.alertOnBlock === false) {
          sendResponse({ ok: true, stored: true, skipped: 'pref' }); return;
        }
        if (alert.action === 'sent_anyway' && o.alertOnSendAnyway === false) {
          sendResponse({ ok: true, stored: true, skipped: 'pref' }); return;
        }
        if (alert.action === 'warned' && o.alertOnWarn === false) {
          sendResponse({ ok: true, stored: true, skipped: 'pref' }); return;
        }
        if (alert.action === 'redacted' && o.alertOnRedact === false) {
          sendResponse({ ok: true, stored: true, skipped: 'pref' }); return;
        }

        const promises = [];

        if (managed) {
          // Managed installs deliver to the worker only. The worker fans out to
          // the channels the IT admin configured server-side, so forward is true.
          promises.push(sendToWorker(alert, true));
          if (o.alertEndpoint && /^https:\/\//i.test(o.alertEndpoint) && isSafeOutboundUrlBg(o.alertEndpoint)) {
            promises.push(swFetch(o.alertEndpoint, {
              method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(alert),
            }).then(r => { if (!r.ok) throw new Error('endpoint ' + r.status); }).catch(() => {}));
          }
        } else {
          const channels = o.channels || {};

          if (channels.slack && channels.slack.enabled && channels.slack.webhookUrl) {
            promises.push(sendSlack(channels.slack.webhookUrl, alert));
          }
          if (channels.teams && channels.teams.enabled && channels.teams.webhookUrl) {
            promises.push(sendTeams(channels.teams.webhookUrl, alert));
          }
          if (channels.telegram && channels.telegram.enabled && channels.telegram.botToken && channels.telegram.chatId) {
            promises.push(sendTelegram(channels.telegram.botToken, channels.telegram.chatId, alert));
          }
          if (channels.webhook && channels.webhook.enabled && channels.webhook.url) {
            promises.push(sendWebhook(channels.webhook.url, alert));
          }
          if (channels.email && channels.email.enabled && channels.email.apiKey && channels.email.to) {
            promises.push(sendEmail(channels.email, alert));
          }
          if (o.alertEndpoint && /^https:\/\//i.test(o.alertEndpoint) && isSafeOutboundUrlBg(o.alertEndpoint)) {
            promises.push(swFetch(o.alertEndpoint, {
              method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(alert),
            }).then(r => { if (!r.ok) throw new Error('endpoint ' + r.status); }).catch(() => {}));
          }
          // Cloud relay: stores the alert for the IT dashboard. forward:false,
          // because the local channels above already handled delivery and the
          // worker must not send duplicates.
          promises.push(sendToWorker(alert, false));
        }

        Promise.allSettled(promises).then((results) => {
          const ok = results.some(r => r.status === 'fulfilled');
          sendResponse({ ok, stored: true, results: results.map(r => r.status) });
        });
      });
    });
  });
}

let auditWriteQueue = Promise.resolve();

function storeAlertLocally(alert) {
  // Serialized on purpose: two catches in the same second used to race the
  // read-modify-write and silently lose the earlier entry.
  auditWriteQueue = auditWriteQueue.then(() => new Promise((resolve) => {
    chrome.storage.local.get(['sg_audit_log'], (r) => {
      const log = r.sg_audit_log || [];
      log.unshift(alert);
      if (log.length > 100) log.length = 100;
      chrome.storage.local.set({ sg_audit_log: log }, () => resolve());
    });
  }));
}

// Every relay result is recorded so the popup can say whether a catch reached
// the console feed. Silent failures were indistinguishable from working sync.
function recordSync(ok, mode, error) {
  try {
    chrome.storage.local.set({
      sg_sync_status: { at: Date.now(), ok: !!ok, mode: mode, error: error ? String(error).slice(0, 120) : '' },
    });
  } catch (e) {}
}

// Clearing the log on the website also clears it here: the console records a
// watermark and every path that talks to the server prunes local rows older
// than it.
function pruneAuditLog(clearedAt) {
  const t = Date.parse(clearedAt || '') || 0;
  if (!t) return;
  chrome.storage.local.get(['sg_audit_log'], (r) => {
    const log = (r.sg_audit_log || []).filter((a) => Date.parse((a && a.timestamp) || '') > t);
    chrome.storage.local.set({ sg_audit_log: log });
  });
}

// Solo Pro: the same catch log lives in the customer console feed, so pushes
// past the warning show up where a team manager would look for them too.
// Returns a promise that settles only once the relay has actually answered.
// The caller does Promise.resolve(sendPersonalAlert(...)) before sendResponse
// on purpose -- it wants the worker held until the push is done, because
// answering first let the worker be terminated in the gap and lost the relay
// while the local log already carried the catch. This returned undefined, so
// that await resolved on the next microtask and the response still went out
// ahead of the storage read, let alone the network.
function sendPersonalAlert(alert) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(['sg_license_key'], (r) => {
        const licenseKey = String(r.sg_license_key || '').trim();
        if (!licenseKey) { recordSync(false, 'personal', 'no license key stored'); resolve(); return; }
        swFetch(WORKER_URL + '/api/license/alert', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ licenseKey, alert }),
          cache: 'no-store',
        }).then((res) => {
          if (res.ok) {
            recordSync(true, 'personal', '');
            res.json().then((data) => pruneAuditLog(data && data.logClearedAt)).catch(() => {});
          } else {
            recordSync(false, 'personal', 'HTTP ' + res.status);
          }
        }).catch((e) => recordSync(false, 'personal', e && e.message ? e.message : 'network error'))
          .then(resolve, resolve);
      });
    } catch (e) { resolve(); }
  });
}

function formatAlertMessage(alert) {
  const actionLabel = {
    blocked: 'Blocked (user cancelled)',
    sent_anyway: 'Sent anyway (user overrode)',
    redacted: 'Redacted by user',
    warned: 'Warned',
  }[alert.action] || alert.action;

  return [
    '🛡️ API Key Leak Intercept Alert',
    '',
    'Employee: ' + alert.userEmail,
    'Site: ' + alert.site,
    'Secret type: ' + alert.secretTypes.join(', ') + ' (' + String(alert.severity || '').toUpperCase() + ')',
    'Action: ' + actionLabel,
    'Time: ' + alert.timestamp,
    'Org: ' + alert.orgId,
    ...(alert.justification ? ['Reason: ' + String(alert.justification).slice(0, 140)] : []),
  ].join('\n');
}

function sendSlack(webhookUrl, alert) {
  return swFetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: formatAlertMessage(alert) }),
  }).then(r => { if (!r.ok) throw new Error('Slack ' + r.status); });
}

function sendTeams(webhookUrl, alert) {
  return swFetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: formatAlertMessage(alert) }),
  }).then(r => { if (!r.ok) throw new Error('Teams ' + r.status); });
}

function sendTelegram(botToken, chatId, alert) {
  return swFetch('https://api.telegram.org/bot' + botToken + '/sendMessage', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text: formatAlertMessage(alert) }),
  }).then(r => { if (!r.ok) throw new Error('Telegram ' + r.status); });
}

function sendWebhook(url, alert) {
  return swFetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(alert),
  }).then(r => { if (!r.ok) throw new Error('Webhook ' + r.status); });
}

function sendEmail(channel, alert) {
  const to = String(channel.to || '').split(',').map(e => e.trim()).filter(Boolean);
  if (to.length === 0) return Promise.reject(new Error('Email no recipients'));
  return swFetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + channel.apiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: RESEND_FROM,
      to,
      subject: 'API Key Leak Intercept Alert: ' + (alert.secretTypes || []).join(', ') + ' on ' + (alert.site || 'unknown'),
      text: formatAlertMessage(alert),
    }),
  }).then(r => { if (!r.ok) throw new Error('Email ' + r.status); });
}

function sendToWorker(alert, forward) {
  return getInstallId().then((installId) => swFetch(WORKER_URL + '/api/alerts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ alert, forward: !!forward, installId }),
    cache: 'no-store',
  })).then(r => {
    recordSync(r.ok, 'org', r.ok ? '' : 'HTTP ' + r.status);
    if (!r.ok) throw new Error('Worker ' + r.status);
  }).catch(e => {
    recordSync(false, 'org', e && e.message ? e.message : 'network error');
    throw e;
  });
}

/* ------------------------------------------------------------------ */
/* Install identity                                                    */
/* A stable per-install id so the console can count seats per machine  */
/* instead of per user email. Generated once, kept in local storage.   */
/* ------------------------------------------------------------------ */
// Memoised for the life of the worker. Two concurrent first-time callers both
// read an empty store and each minted its own id, and the last write won, so
// one machine reported two seats for the following month. The heartbeat and
// the alert relay reach this at the same moment on a restored session.
let installIdPromise = null;
function getInstallId() {
  if (installIdPromise) return installIdPromise;
  installIdPromise = new Promise((resolve) => {
    chrome.storage.local.get(['sg_install_id'], (m) => {
      if (m.sg_install_id) return resolve(m.sg_install_id);
      const id = (typeof crypto !== 'undefined' && crypto.randomUUID)
        ? crypto.randomUUID().replace(/-/g, '')
        : (String(Date.now()) + Math.random()).replace(/[^a-z0-9]/gi, '').slice(0, 32);
      chrome.storage.local.set({ sg_install_id: id }, () => resolve(id));
    });
  });
  return installIdPromise;
}

/* ------------------------------------------------------------------ */
/* Heartbeat                                                           */
/* ------------------------------------------------------------------ */
async function doHeartbeat() {
  try {
    const org = await new Promise((resolve) => getEffectiveOrg(resolve));
    if (!org.teamMode || !org.orgId || !org.heartbeat) return;
    const managed = await new Promise((resolve) => withManagedState(resolve));
    const payload = {
      orgId: org.orgId,
      orgToken: org.orgToken || '',
      userEmail: org.userEmail || 'unknown',
      extensionVersion: chrome.runtime.getManifest().version,
      managed: !!managed,
      installId: await getInstallId(),
      timestamp: new Date().toISOString(),
    };
    const url = (org.alertEndpoint && /^https:\/\//i.test(org.alertEndpoint) && isSafeOutboundUrlBg(org.alertEndpoint)) ? org.alertEndpoint.replace(/\/$/, '') + '/heartbeat' : (WORKER_URL + '/api/heartbeat');
    await swFetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), cache: 'no-store' }).catch(() => {});
  } catch (e) {}
}

chrome.runtime.onStartup.addListener(() => { try { ensureAlarms(); } catch (e) {} try { doHeartbeat(); } catch (e) {} try { fetchConfig(); } catch (e) {} try { checkEntitlement(); } catch (e) {} try { syncDynamicContentScript(); } catch (e) {} });

const CONFIG_URL = WORKER_URL + '/api/config';

importScripts('configverify.js', 'entitlement-state.js');

async function fetchConfig() {
  try {
    const res = await swFetch(CONFIG_URL, { cache: 'no-store' });
    if (!res.ok) throw new Error('fetch ' + res.status);
    const raw = await res.text();
    if (raw.length > 64 * 1024) throw new Error('too large');
    const stored = await new Promise((resolve) => chrome.storage.local.get(['sg_config_seq'], resolve));
    const verified = await SGConfigVerify.verifyEnvelope(JSON.parse(raw), undefined, undefined, stored.sg_config_seq || 0);
    if (!verified.ok) return;
    await new Promise((resolve) => chrome.storage.local.set({
      sg_config: verified.data,
      sg_config_at: Date.now(),
      sg_config_seq: verified.seq,
      sg_config_exp: verified.exp,
    }, resolve));
  } catch (e) {
    // fall back to cached last good config (already in storage)
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'heartbeat') { doHeartbeat(); return; }
  if (alarm.name === 'configCheck') { fetchConfig(); return; }
  if (alarm.name !== 'licenseCheck') return;
  // Daily Pro revalidation: revoke only on a definitive "invalid" answer.
  // Gated on the key alone, not on sg_isPro as well. Requiring both meant a
  // licence that failed verification once was never checked again, so a
  // transient KV miss right after purchase, or a dunning blip that later
  // cleared, latched a paying user to free until they happened to open the
  // popup. The revocation latch has to be two-way to be worth anything.
  chrome.storage.local.get(['sg_license_key', 'sg_isPro'], (res) => {
    if (res.sg_license_key) verifyLicense(res.sg_license_key, () => {});
  });
  checkEntitlement();
});
